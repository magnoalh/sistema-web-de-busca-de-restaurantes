# sistema-web-de-busca-de-restaurantes

Objetivo desse projeto é construir um sistema web de busca de restaurantes, parecido com o serviço que o Google oferece. Vamos desenvolver esse buscador usando React.JS e API do Google, iniciando do zero à nuvem.
